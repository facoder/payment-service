package com.payment.server;

import com.payment.server.component.PaymentHttpServer;
import com.payment.server.utils.PropertyUtil;

public class Application {

    private static final int DEFAULT_SERVER_PORT = 8090;

    public static void main(String[] args) {
        PaymentHttpServer paymentHttpServer = new PaymentHttpServer();
        paymentHttpServer.start(serverPort(args));
    }

    private static int serverPort(String[] args) {
        String serverPort = PropertyUtil.getProperty(args, "serverPort");
        try {
            if (serverPort == null) {
                return DEFAULT_SERVER_PORT;
            }
            return Integer.parseInt(serverPort);
        } catch (NumberFormatException e) {
            return DEFAULT_SERVER_PORT;
        }
    }
}
