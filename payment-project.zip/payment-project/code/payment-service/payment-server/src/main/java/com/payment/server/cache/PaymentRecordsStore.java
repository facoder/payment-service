package com.payment.server.cache;

import com.alibaba.fastjson.JSON;
import com.payment.server.entity.PaymentRecord;
import io.muserver.SsePublisher;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class PaymentRecordsStore {
    private static final Map<String, PaymentRecord> paymentRecordsStore = new ConcurrentHashMap<>();

    private static final Notifier notifier = new Notifier();

    private PaymentRecordsStore() {
    }

    static {
        new Thread(notifier, "notifier-payment-thread").start();
    }


    public static List<PaymentRecord> getPaymentRecords() {
        return new ArrayList<>(paymentRecordsStore.values());
    }

    public static PaymentRecord getPaymentRecord(String currencyCode) {
        return paymentRecordsStore.get(currencyCode);
    }

    public static void addPaymentRecords(List<PaymentRecord> paymentRecords) {
        notifier.addTask(paymentRecords);
    }

    private static void refreshPaymentRecords(List<PaymentRecord> paymentRecords) {
        for (PaymentRecord paymentRecord : paymentRecords) {
            refreshPaymentRecord(paymentRecord);
        }
    }

    private static void refreshPaymentRecord(PaymentRecord paymentRecord) {
        PaymentRecord cachePaymentRecord = paymentRecordsStore.get(paymentRecord.getCurrencyCode());
        if (cachePaymentRecord == null) {
            paymentRecordsStore.put(paymentRecord.getCurrencyCode(), paymentRecord);
            return;
        }
        BigDecimal calculatedAmounts = cachePaymentRecord.getAmounts().add(paymentRecord.getAmounts());
        cachePaymentRecord.setAmounts(calculatedAmounts);


        List<SsePublisher> subscribers = PaymentSubscribersCache
                .getSubscribersByCurrencyCode(cachePaymentRecord.getCurrencyCode());
        if (subscribers == null || subscribers.isEmpty()) {
            return;
        }
        String paymentJson = JSON.toJSONString(cachePaymentRecord);
        for (SsePublisher subscriber : subscribers) {
            try {
                subscriber.send(paymentJson);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static class Notifier implements Runnable {
        private final BlockingQueue<List<PaymentRecord>> tasks = new LinkedBlockingQueue<>();

        public void addTask(List<PaymentRecord> paymentRecords) {
            tasks.offer(paymentRecords);
        }

        @Override
        public void run() {
            for (; ; ) {
                try {
                    List<PaymentRecord> paymentRecords = tasks.take();
                    refreshPaymentRecords(paymentRecords);
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
