package com.payment.server.entity;

import java.math.BigDecimal;

public class PaymentRecord {

    private String currencyCode;

    private BigDecimal amounts;

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public BigDecimal getAmounts() {
        return amounts;
    }

    public void setAmounts(BigDecimal amounts) {
        this.amounts = amounts;
    }

    @Override
    public String toString() {
        return currencyCode + " " + amounts;
    }
}
