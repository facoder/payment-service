package com.payment.server.handler;

import com.alibaba.fastjson.JSON;
import com.payment.server.cache.PaymentRecordsStore;
import com.payment.server.entity.PaymentRecord;
import io.muserver.Method;
import io.muserver.MuRequest;
import io.muserver.MuResponse;
import io.muserver.SsePublisher;

import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class QueryAllPaymentsHttpHandler implements HttpHandler {
    @Override
    public Method getMethod() {
        return Method.GET;
    }

    @Override
    public String getUrl() {
        return "/query/payments";
    }

    @Override
    public void handle(MuRequest request, MuResponse response, Map<String, String> pathParams) throws Exception {
        SsePublisher publisher = SsePublisher.start(request, response);
        new Thread(() -> {
            while (true) {
                try {
                    List<PaymentRecord> paymentRecords = PaymentRecordsStore.getPaymentRecords();
                    publisher.send(JSON.toJSONString(paymentRecords));
                    Thread.sleep(TimeUnit.MINUTES.toMillis(1));
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Thread.currentThread().interrupt();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        }, "query-payments-thread").start();

    }
}
