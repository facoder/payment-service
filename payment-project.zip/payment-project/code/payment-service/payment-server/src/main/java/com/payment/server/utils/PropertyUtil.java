package com.payment.server.utils;

public class PropertyUtil {

    public static String getProperty(String[] args, String propertyName) {
        if (args.length >= 1) {
            return args[0].replace("-D" + propertyName + "=", "");
        }
        return System.getProperty(propertyName);
    }
}
