package com.payment.server.cache;

import io.muserver.SsePublisher;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class PaymentSubscribersCache {

    private PaymentSubscribersCache() {
    }

    private static final Map<String, List<SsePublisher>> subscribersCache = new ConcurrentHashMap<>();

    public static synchronized void addSubscriber(String currencyCode, SsePublisher subscriber) {
        List<SsePublisher> subscribers = subscribersCache.get(currencyCode);
        if (subscribers == null) {
            subscribers = new ArrayList<>();
            subscribers.add(subscriber);
            subscribersCache.put(currencyCode, subscribers);
            return;
        }
        subscribers.add(subscriber);
    }

    public static List<SsePublisher> getSubscribersByCurrencyCode(String currencyCode) {
        return subscribersCache.get(currencyCode);
    }
}
