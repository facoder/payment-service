package com.payment.server.handler;

import com.payment.server.cache.PaymentSubscribersCache;
import io.muserver.Method;
import io.muserver.MuRequest;
import io.muserver.MuResponse;
import io.muserver.SsePublisher;

import java.util.Map;

public class UpdatePaymentHttpHandler implements HttpHandler {

    @Override
    public Method getMethod() {
        return Method.GET;
    }

    @Override
    public String getUrl() {
        return "/subscribe/payment/currency/{code}";
    }

    @Override
    public void handle(MuRequest request, MuResponse response, Map<String, String> pathParams) throws Exception {
        String currencyCode = pathParams.get("code");
        SsePublisher publisher = SsePublisher.start(request, response);
        PaymentSubscribersCache.addSubscriber(currencyCode, publisher);
    }
}
