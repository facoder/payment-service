package com.payment.server.component;

import com.payment.server.handler.HttpHandler;
import com.payment.server.handler.AddPaymentHttpHandler;
import com.payment.server.handler.QueryAllPaymentsHttpHandler;
import com.payment.server.handler.QueryPaymentHttpHandler;
import com.payment.server.handler.UpdatePaymentHttpHandler;
import io.muserver.MuServer;
import io.muserver.MuServerBuilder;

import java.util.ArrayList;
import java.util.List;

public class PaymentHttpServer {

    private final List<HttpHandler> httpHandlers = new ArrayList<>();

    public void start(int port) {
        initHandlers();

        MuServerBuilder muServerBuilder = MuServerBuilder.httpServer().withHttpPort(port);

        for (HttpHandler httpHandler : httpHandlers) {
            muServerBuilder.addHandler(httpHandler.getMethod(), httpHandler.getUrl(), httpHandler);
        }
        MuServer server = muServerBuilder.start();
        System.out.println("Started server at " + server.uri());
    }

    private void initHandlers() {
        httpHandlers.add(new QueryPaymentHttpHandler());
        httpHandlers.add(new UpdatePaymentHttpHandler());
        httpHandlers.add(new AddPaymentHttpHandler());
        httpHandlers.add(new QueryAllPaymentsHttpHandler());
    }
}
