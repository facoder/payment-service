package com.payment.server.handler;

import io.muserver.Method;
import io.muserver.RouteHandler;

public interface HttpHandler extends RouteHandler {

    /**
     * get http method
     * @return
     */
    Method getMethod();

    /**
     * get http url
     * @return
     */
    String getUrl();
}
