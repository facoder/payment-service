package com.payment.server.handler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.payment.server.cache.PaymentRecordsStore;
import com.payment.server.entity.PaymentRecord;
import io.muserver.Method;
import io.muserver.MuRequest;
import io.muserver.MuResponse;

import java.util.List;
import java.util.Map;

public class AddPaymentHttpHandler implements HttpHandler {
    @Override
    public Method getMethod() {
        return Method.POST;
    }

    @Override
    public String getUrl() {
        return "/add/payment";
    }

    @Override
    public void handle(MuRequest request, MuResponse response, Map<String, String> pathParams) throws Exception {
        String json = request.readBodyAsString();
        List<PaymentRecord> paymentRecords = JSON.parseObject(json, new TypeReference<List<PaymentRecord>>() {
        });
        PaymentRecordsStore.addPaymentRecords(paymentRecords);
    }
}
