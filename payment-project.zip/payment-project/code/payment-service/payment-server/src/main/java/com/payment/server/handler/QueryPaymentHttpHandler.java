package com.payment.server.handler;

import com.alibaba.fastjson.JSON;
import com.payment.server.cache.PaymentRecordsStore;
import com.payment.server.entity.PaymentRecord;
import io.muserver.Method;
import io.muserver.MuRequest;
import io.muserver.MuResponse;

import java.util.Map;

public class QueryPaymentHttpHandler implements HttpHandler {
    @Override
    public Method getMethod() {
        return Method.GET;
    }

    @Override
    public String getUrl() {
        return "/query/payment/currency/{code}";
    }

    @Override
    public void handle(MuRequest request, MuResponse response, Map<String, String> pathParams) throws Exception {
        String currencyCode = pathParams.get("code");
        PaymentRecord paymentRecord = PaymentRecordsStore.getPaymentRecord(currencyCode);
        response.write(JSON.toJSONString(paymentRecord));
    }
}
