package com.payment.client.entity;

import java.math.BigDecimal;

public class PaymentRecord {

    private String currencyCode;

    private BigDecimal amounts;

    public PaymentRecord(String currencyCode, BigDecimal amounts) {
        this.currencyCode = currencyCode;
        this.amounts = amounts;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public BigDecimal getAmounts() {
        return amounts;
    }

    public void setAmounts(BigDecimal amounts) {
        this.amounts = amounts;
    }

    public static BigDecimal convert2Amounts(String str) {
        try {
            return new BigDecimal(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public String toString() {
        return currencyCode + " " + amounts;
    }
}
