package com.payment.client.component;

import com.payment.client.entity.PaymentRecord;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ConsolePrinter {

    private ConsolePrinter() {
    }

    public static void printInvalidMessage(Map<String, String> invalidMessage) {
        StringBuilder str = new StringBuilder();
        for (Map.Entry<String, String> entry : invalidMessage.entrySet()) {
            str.append("Line:'").append(entry.getKey()).append("', Error:'").append(entry.getValue()).append("'.\n");
        }
        System.out.println(str);
    }

    public static void printHelpInfo() {
        System.out.println(
                "Please enter the payment record to be added, press enter to wrap multiple records.\nYou need to press enter twice in a row to end the entry. \nIn addition, you can also enter quit to exit the program.");
    }

    public static void printAllPaymentRecords(List<PaymentRecord> paymentRecords) {
        String paymentRecordsInfo = paymentRecords.stream().filter(paymentRecord -> paymentRecord.getAmounts() != null
                && paymentRecord.getAmounts().compareTo(BigDecimal.ZERO) > 0).map(PaymentRecord::toString)
                .collect(Collectors.joining("\n"));
        if (StringUtils.hasText(paymentRecordsInfo)) {
            String printInfo = "--------------------Start print all payment records-------------------\n";
            printInfo += paymentRecordsInfo + "\n";
            printInfo += "--------------------End print all payment records-------------------\n";
            System.out.println(printInfo);
        }
    }

    public static void printStartProcesFile() {
        System.out.println(
                "Start process the payment information of the specified file-------------------\n");
    }

    public static void printEndProcesFile() {
        System.out.println(
                "End process the payment information of the specified file-------------------\n");
    }

    public static void printStartSendPaymentToRemote() {
        System.out.println(
                "Start sending new payment records to the remote end-------------------\n");
    }

    public static void printEndSendPaymentToRemote() {
        System.out.println(
                "End sending new payment records to the remote end-------------------\n");
    }
}
