package com.payment.client.utils;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class FileUtil {

    public static List<String> getFileContent(String filePath) {
        List<String> content = new ArrayList<>();
        try (Stream<String> input = Files.lines(Paths.get(filePath))) {
            input.forEach(content::add);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return content;
    }
}
