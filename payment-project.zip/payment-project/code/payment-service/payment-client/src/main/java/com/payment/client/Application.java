package com.payment.client;

import com.payment.client.component.ConsolePrinter;
import com.payment.client.component.PaymentHttpClient;
import com.payment.client.component.PaymentRecordsProcessor;
import com.payment.client.entity.PaymentRecord;
import com.payment.client.utils.CharacterUtil;
import com.payment.client.utils.FileUtil;
import com.payment.client.utils.PropertyUtil;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Application {
    private static final int DEFAULT_SERVER_PORT = 8090;

    public static void main(String[] args) {

        // 1. initialize http client
        PaymentHttpClient.init(serverPort(args));

        // 2.Print payment records
        PaymentRecordsProcessor.printPaymentRecords();

        // 3. Process special file
        processFile(args);

        // 4.Process user input commands
        processUserInputCmd();

    }

    private static int serverPort(String[] args) {
        String serverPort = PropertyUtil.getProperty(args, "serverPort");
        try {
            if (serverPort == null) {
                return DEFAULT_SERVER_PORT;
            }
            return Integer.parseInt(serverPort);
        } catch (NumberFormatException e) {
            return DEFAULT_SERVER_PORT;
        }
    }

    private static void processFile(String[] args) {
        String filePath = PropertyUtil.getProperty(args, "filePath");
        if (!StringUtils.hasText(filePath)) {
            return;
        }
        ConsolePrinter.printStartProcesFile();
        List<String> fileContent = FileUtil.getFileContent(filePath);
        processInputAndSendToRemote(fileContent, false);
        ConsolePrinter.printEndProcesFile();
    }

    private static void processUserInputCmd() {
        Scanner scanner = new Scanner(System.in);
        ConsolePrinter.printHelpInfo();
        List<String> needProcessText = new ArrayList<>();
        while (true) {
            String input = scanner.nextLine().trim();
            if ("".equals(input)) {
                processInputAndSendToRemote(needProcessText, true);
                continue;
            }
            if ("quit".equals(input)) {
                break;
            }
            needProcessText.add(input);
        }
    }

    private static void processInputAndSendToRemote(List<String> needProcessText, boolean needPrintInfo) {

        // 1. Filter out invalid input
        Map<String, String> invalidMessage = new HashMap<>();
        List<PaymentRecord> paymentRecords = filterInvalidInput(needProcessText, invalidMessage);

        // 2. Add legal payment records to the remote end
        PaymentRecordsProcessor.sendPaymentRecordsToRemote(paymentRecords);

        //3. Print information
        if (needPrintInfo) {
            ConsolePrinter.printInvalidMessage(invalidMessage);
            ConsolePrinter.printHelpInfo();
        }

        //4. clear cache
        needProcessText.clear();
    }

    private static List<PaymentRecord> filterInvalidInput(List<String> needProcessText,
            Map<String, String> invalidMessage) {
        if (needProcessText.isEmpty()) {
            return Collections.emptyList();
        }
        return needProcessText.stream().map(input -> convert2PaymentRecord(invalidMessage, input))
                .filter(Objects::nonNull).collect(Collectors.toList());
    }

    private static PaymentRecord convert2PaymentRecord(Map<String, String> invalidMessage, String input) {
        if (!StringUtils.hasText(input)) {
            invalidMessage.put(input, "Payment record cannot be empty!");
            return null;
        }
        String[] split = input.split("\\s+");
        if (split.length <= 1) {
            invalidMessage.put(input, "Payment record does not conform to format!");
            return null;
        }
        if (CharacterUtil.isNotUpper3Letter(split[0])) {
            invalidMessage.put(input, "Currency code must be any uppercase 3-letter code!");
            return null;
        }
        BigDecimal amounts = PaymentRecord.convert2Amounts(split[1]);
        if (amounts == null) {
            invalidMessage.put(input, "Amounts do not conform to the format!");
        }
        return new PaymentRecord(split[0], amounts);
    }


}
