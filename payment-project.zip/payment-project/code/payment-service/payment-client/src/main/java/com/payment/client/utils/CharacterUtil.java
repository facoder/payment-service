package com.payment.client.utils;

public class CharacterUtil {

    public static boolean isNotUpper3Letter(String s) {
        return s.length() != 3 || !isUpperCase(s);
    }

    public static boolean isUpperCase(String str) {
        for (char c : str.toCharArray()) {
            if (!Character.isLetter(c) || Character.isLowerCase(c)) {
                return false;
            }
        }
        return true;
    }
}
