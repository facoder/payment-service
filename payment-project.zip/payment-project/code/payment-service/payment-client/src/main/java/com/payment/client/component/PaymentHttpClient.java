package com.payment.client.component;

import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.function.Consumer;

public class PaymentHttpClient {


    private PaymentHttpClient() {
    }

    private static WebClient webClient;

    public static void init(int serverPort) {
        webClient = WebClient.builder().baseUrl("http://localhost:" + serverPort).build();
    }

    public static void syncPost(String url, String json) {
        webClient.post().uri(url).body(Mono.just(json), String.class).exchange().block();
    }

    public static void ayncGet(String url, Consumer<String> callback) {
        webClient.get().uri(url).accept(MediaType.APPLICATION_STREAM_JSON).exchange()
                .flatMapMany(response -> response.bodyToFlux(String.class)).doOnNext(callback).subscribe();
    }
}
