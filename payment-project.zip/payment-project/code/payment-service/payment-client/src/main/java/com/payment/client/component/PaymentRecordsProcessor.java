package com.payment.client.component;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.TypeReference;
import com.payment.client.entity.PaymentRecord;

import java.util.List;

public class PaymentRecordsProcessor {

    private static boolean firstConnectRemote = true;

    private PaymentRecordsProcessor() {
    }

    public static void sendPaymentRecordsToRemote(List<PaymentRecord> paymentRecords) {
        if (paymentRecords.isEmpty()) {
            return;
        }
        ConsolePrinter.printStartSendPaymentToRemote();
        PaymentHttpClient.syncPost("/add/payment", JSON.toJSONString(paymentRecords));
        ConsolePrinter.printEndSendPaymentToRemote();
    }

    public static void printPaymentRecords() {
        PaymentHttpClient.ayncGet("/query/payments", body -> {
            List<PaymentRecord> paymentRecords = JSON.parseObject(body, new TypeReference<List<PaymentRecord>>() {
            });
            if (!firstConnectRemote) {
                ConsolePrinter.printAllPaymentRecords(paymentRecords);
            }
            firstConnectRemote = false;
        });
    }

}
