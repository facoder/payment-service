package com.payment.client.utils;

public class PropertyUtil {

    public static String getProperty(String[] args, String propertyName) {
        if (args.length >= 1) {
            return args[0].replace("-D" + propertyName + "=", "");
        }
        return System.getProperty(propertyName);
    }
}
